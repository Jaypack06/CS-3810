"""
CS3810 Mini-Project 1 - Part 1: The Environment (30 points)
============================================================

Implement the VacuumWorld class below. Do not change any method name or
signature: run_tests.py and the grading harness call them exactly as written.

Reminders from the handout (Section 1.2):

  * A state is ((row, col), frozenset_of_dirty_cells). It must be HASHABLE,
    because your searches will put states into sets and dictionaries. Use a
    tuple for the position and a frozenset for the dirt - a plain set will
    raise TypeError the first time you add it to your explored set.

  * result() must NOT mutate the state it is given. Build and return a new
    one. This is the single most common bug in this project: if you mutate,
    every state sitting in your frontier silently becomes the same state.

  * get_actions() must return actions in the canonical order below, filtered
    down to the legal ones. Illegal actions are never generated: no CLEAN in
    a clean cell, no move into a wall or an obstacle. Determinism here is
    what makes your node counts comparable with everyone else's.
"""

# The canonical action order. Filter this list; do not reorder it.
ACTION_ORDER = ['MOVE_UP', 'MOVE_DOWN', 'MOVE_LEFT', 'MOVE_RIGHT', 'CLEAN']

# Row/column offsets for the four movement actions.
DELTAS = {
    'MOVE_UP': (-1, 0),
    'MOVE_DOWN': (1, 0),
    'MOVE_LEFT': (0, -1),
    'MOVE_RIGHT': (0, 1),
}


class VacuumWorld:
    """A vacuum-cleaning robot problem on a rectangular grid."""

    def __init__(self, grid, start, dirty):
        self.grid = grid
        self.start = start
        self.rows = len(grid)
        self.cols = len(grid[0])
        self.dirty = frozenset(dirty)
        
        """
        Args:
            grid:  List of strings or list of lists; '#' marks an obstacle.
            start: Tuple (row, col) - the robot's starting position.
            dirty: Iterable of (row, col) tuples that begin dirty.

        Suggested attributes to set here: self.grid, self.rows, self.cols,
        self.start, self.dirty.
        """
        #raise NotImplementedError("Part 1: implement VacuumWorld.__init__")

    # -- helpers ---------------------------------------------------------
    # These two are not graded directly and not called by the test harness,
    # but get_actions() and result() are much shorter if you write them.

    def in_bounds(self, pos):
        """Return True if pos is inside the grid."""
        return 0 <= pos[0] < self.rows and 0 <= pos[1] < self.cols
        
        #raise NotImplementedError("Part 1: implement in_bounds (optional)")

    def is_passable(self, pos):
        """Return True if pos is in bounds and is not an obstacle."""
        return self.in_bounds(pos) and self.grid[pos[0]][pos[1]] != '#'
        
        #raise NotImplementedError("Part 1: implement is_passable (optional)")

    # -- problem interface -----------------------------------------------

    def initial_state(self):
        """Return the initial state as ((row, col), frozenset(dirty))."""

        return (self.start, self.dirty)
        #raise NotImplementedError("Part 1: implement initial_state")

    def is_goal(self, state):
        """Return True if the dirty set in `state` is empty."""
        _, dirty = state
        return not dirty
        #raise NotImplementedError("Part 1: implement is_goal")

    def get_actions(self, state):
        """Return a list of legal action names available in `state`.

        Legal means: moves stay in bounds and off obstacles, and CLEAN is
        only offered when the robot's current cell is dirty. Return the
        actions in ACTION_ORDER order.
        """
        (r, c), dirty = state
        legal = []
        for action in ACTION_ORDER:
            if action == 'CLEAN':
                if (r, c) in dirty:
                    legal.append(action)
            else:
                dr, dc = DELTAS[action]
                nr, nc = r + dr, c + dc
                if self.is_passable((nr, nc)):
                    legal.append(action)
        return legal
        #raise NotImplementedError("Part 1: implement get_actions")

    def result(self, state, action):
        """Return the successor state produced by applying `action`.

        Must not modify `state`.
        """
        (r, c), dirty = state
        if action == 'CLEAN':
            return ((r, c), dirty - {(r, c)})
        dr, dc = DELTAS[action]
        return ((r + dr, c + dc), dirty)
        #raise NotImplementedError("Part 1: implement result")

    def action_cost(self, state, action):
        """Return the cost of `action` in `state` (always 1 here)."""
        return 1
        #raise NotImplementedError("Part 1: implement action_cost")

    # -- debugging -------------------------------------------------------

    def render(self, state=None):
        
        """Return a printable picture of `state` (defaults to the initial state).

        Use the same characters as test_grids.py: '#' obstacle, 'R' robot,
        'D' dirty, '*' robot on a dirty cell, '.' clean and empty.

        This is not graded for correctness, but you will use it constantly
        while debugging. Write it first.
        """
        #raise NotImplementedError("Part 1: implement render")
        if state is None:
            state = self.initial_state()
        (r_pos, c_pos), dirty = state

        lines = []
        for r in range(self.rows):
            row_chars = []
            for c in range(self.cols):
                if (r, c) == (r_pos, c_pos) and (r, c) in dirty:
                    ch = '*'
                elif (r, c) == (r_pos, c_pos):
                    ch = 'R'
                elif (r, c) in dirty:
                    ch = 'D'
                elif self.grid[r][c] == '#':
                    ch = '#'
                else:
                    ch = '.'
                row_chars.append(ch)
            lines.append(''.join(row_chars))
        return '\n'.join(lines)

    def __str__(self):
        return self.render()


if __name__ == "__main__":
    # Quick manual check once you have implemented the class:
    from test_grids import EXAMPLE, parse_grid

    grid, start, dirty = parse_grid(EXAMPLE)
    problem = VacuumWorld(grid, start, dirty)
    print(problem.render())
    print("initial state:", problem.initial_state())
    print("legal actions:", problem.get_actions(problem.initial_state()))

    